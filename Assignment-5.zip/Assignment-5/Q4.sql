CREATE SCHEMA Sales;
GO

CREATE TABLE Sales.Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    CustomerID INT,
    TotalAmount DECIMAL(10, 2)
);

CREATE TABLE Sales.Customers (
    CustomerID INT PRIMARY KEY,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Email NVARCHAR(100)
);

CREATE TABLE Sales.Products (
    ProductID INT PRIMARY KEY,
    ProductName NVARCHAR(100),
    Price DECIMAL(10, 2)
);

CREATE TABLE Sales.OrderDetails (
    OrderDetailID INT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT,
    FOREIGN KEY (OrderID) REFERENCES Sales.Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Sales.Products(ProductID)
);
GO

-- Insert sample data into source tables
INSERT INTO Sales.Orders VALUES (1, '2024-01-01', 1, 100.00), (2, '2024-02-01', 2, 150.00);
INSERT INTO Sales.Customers VALUES (1, 'Sohan', 'Mohanty', 'sohan@gmail.com'), (2, 'Kartik', 'Rama Rao', 'thalaiva@gmail.com');
INSERT INTO Sales.Products VALUES (1, 'Product A', 10.00), (2, 'Product B', 20.00);
INSERT INTO Sales.OrderDetails VALUES (1, 1, 1, 5), (2, 1, 2, 2), (3, 2, 1, 1), (4, 2, 2, 3);
GO

CREATE SCHEMA Sale;
GO

SELECT OrderID, OrderDate 
INTO Sale.Orders 
FROM Sales.Orders;

SELECT CustomerID, FirstName, LastName 
INTO Sale.Customers 
FROM Sales.Customers;

SELECT ProductID, ProductName 
INTO Sale.Products 
FROM Sales.Products;

SELECT OrderID, ProductID, Quantity 
INTO Sale.OrderDetails 
FROM Sales.OrderDetails;
GO