-- Create table in the source database
CREATE DATABASE FirstDatabase;
GO

USE FirstDatabase;
GO

CREATE TABLE Table1 (
    id INT PRIMARY KEY,
    name NVARCHAR(100)
);

CREATE TABLE Table2 (
    id INT PRIMARY KEY,
    description NVARCHAR(100)
);

INSERT INTO Table1 (id, name)
VALUES
    (1, 'Sovan'),
    (2, 'Kartik'),
    (3, 'Dezy');

INSERT INTO Table2 (id, description)
VALUES
    (1, 'Employee'),
    (2, 'Manager'),
    (3, 'Secretary');
GO

CREATE DATABASE SecondDatabase;
GO

USE SecondDatabase;
GO

SELECT * INTO SecondDatabase.dbo.Table1 FROM FirstDatabase.dbo.Table1;
SELECT * INTO SecondDatabase.dbo.Table2 FROM FirstDatabase.dbo.Table2;
GO


