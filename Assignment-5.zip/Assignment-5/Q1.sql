CREATE TABLE Demo_table (
    id INT PRIMARY KEY,
    name NVARCHAR(100),
    age INT,
    email NVARCHAR(100),
    join_date DATE
);

INSERT INTO Demo_table (id, name, age, email, join_date)
VALUES
    (1, 'Sohan', 30, 'sohan2213@example.com', '2022-01-15'),
    (2, 'Jack', 25, 'thesparrowedpirate@example.com', '2023-03-22'),
    (3, 'Nick', 35, 'itsnicknotnikhil@example.com', '2021-07-10'),
    (4, 'Rahul', 28, 'theunheardname@example.com', '2024-05-18'),
    (5, 'Patty', 40, 'shami27@example.com', '2020-11-02');

GO
CREATE PROCEDURE sp_export_data_to_csv
AS
BEGIN
    DECLARE @bcp_command NVARCHAR(4000)
    SET @bcp_command = 'bcp "SELECT * FROM Demo_table" queryout "Demo.csv" -c -t, -S SOHAN -U SOHAN\mohanty -P Sohan@2213'
    EXEC master..xp_cmdshell @bcp_command
END
GO
CREATE PROCEDURE sp_export_data_to_parquet
AS
BEGIN
    DECLARE @parquet_command NVARCHAR(4000)
    SET @parquet_command = 'python -m sqlmlutils.parquet_export --server SOHAN --database Demo --username SOHAN\mohanty --password Sohan@2213 --query "SELECT * FROM Demo_table" --output "Parquet"'
    EXEC master..xp_cmdshell @parquet_command
END
GO
CREATE PROCEDURE sp_export_data_to_avro
AS
BEGIN
    DECLARE @avro_command NVARCHAR(4000)
    SET @avro_command = 'python -m sqlavro.export --server SOHAN --database Demo --username SOHAN\mohanty --password Sohan@2213 --query "SELECT * FROM Demo_table" --output "Avro"'
    EXEC master..xp_cmdshell @avro_command
END
GO